#ifndef MENU_MANAGER_H_INCLUDED
#define MENU_MANAGER_H_INCLUDED

#include<vector>

//!< menu function
typedef void (*MenuItemHandler)(void* pParam);

typedef struct _MenuItem
{
    int xPos,yPos,index;  //!< menu location
    int width,height;     //!< menu high and width
    float x,y;

    //!< menu handler
    MenuItemHandler handler;
    void* pParam;

    //!<picture data
    unsigned char *imgNormal;
    unsigned char *imgHover;
    unsigned char *imgClicked;
    unsigned char *imgCurrent;

    short level;
    bool active;        //!< activiton state
    bool posFixed;      //!< position
    bool clicked;       //!< mouse click

    void* user_data;
}MenuItem;

class Game;

class MenuManager
{
public:
    MenuManager();
    ~MenuManager();

    bool intialize(Game* game,int width,int height);
    void cleanup();

    void newScreenSize(int width,int height);   //!<��resize windows

    //!< add new menu item
    void addNewItem(char* szNormal,char* szHover,char* szSelected,
                    int posX,int posY,
                    MenuItemHandler handler,void *param,
                    short level,
                    bool active=false,bool fixed=false);

    //!< mouse location
    void processMouseMove(float x,float y);

    //!< mouse click location
    void processMouseClicked(int button,int action);

    void drawMenuItems();               //!< draw menu
    void ShowSubMenu(int level,bool bShow=true);  //!< main menu
    //void ShowSettings();

    void showLevelSubMenu(bool bShow);

private:
    std::vector<MenuItem*> vecMenuItem; //!< save all menu

    float screenWidth,screenHeight;     //!< screen high and width

    float mouseX,mouseY;                //!< mouse location

    void hover_menuitem(MenuItem*);     //!< call this function when mouse location changed
    void click_menuitem(MenuItem*);     //!< call this function when mouse release or press
};


#endif // MENU_MANAGER_H_INCLUDED
