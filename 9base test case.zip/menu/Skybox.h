#ifndef SKYBOX_H_INCLUDED
#define SKYBOX_H_INCLUDED

#include "StandardObject.h"

class Skybox : public StandardObject {

    public:

        Skybox(float x, float y, int bgNum);

};

#endif // SKYBOX_H_INCLUDED
