
#ifndef TESTCASE_H_INCLUDED
#define TESTCASE_H_INCLUDED

#define TEST_CASE

#include "IncludeObjects.h"
#include "Environment.h"

void SetHeroObject(Hero *hero);
void SetEnvironment(Environment *env);
void TestCaseUpdate(bool gamePause);
bool IsTesting();

#endif // TESTCASE_H_INCLUDED
