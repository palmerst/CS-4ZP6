#include "Hero.h"

Hero::Hero(float x, float y) : DynamicObject(x, y, 200.0f, 100.0f, 0.0f, 0.0f, OBJ_HERO, "./data/obj/testchar", "./data/shader/vObject.glsl", "./data/shader/fObject.glsl") {

    cpBodySetMoment(body, INFINITY);
    startPos = cpv(x, y);

    canJump = false;
    soundOn = true;
}

void Hero::death(){

    if(soundOn==true)
    {
        Sound* sound = soundStore.add("./data/sound/scream.wav");
        sound->play();
    }

    cpBodySetPosition(body, startPos);
    cpBodySetVelocity(body, cpvzero);
}

void Hero::toTheStart()
{
    cpBodySetPosition(body, startPos);
    cpBodySetVelocity(body, cpvzero);
}
