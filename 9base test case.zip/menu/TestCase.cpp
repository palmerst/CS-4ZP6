
#include <stdio.h>

#include "TestCase.h"
#include "include/GLFW/glfw3.h"

static double timeElapsed = 0.0;
static double timeLast = 0.0;
static double timePrintElapsed = 0.0;
static const double TIME_SKIP = 10.0;
static Hero *s_hero;
static Environment *s_env;
float time_flag_for_case5=0;
float time_flag_for_case9=0;

static int current = 0;
float last_velocity=0;
float current_velocity=0;
float temp_velocity=0;
#ifdef TEST_CASE
static bool bTesting = true;
#else
static bool bTesting = false;
#endif

void SetHeroObject(Hero *hero)
{
    s_hero = hero;
}

void SetEnvironment(Environment *env)
{
    s_env = env;
}

void TestCaseUpdate(bool gamePause)
{
    if(gamePause==true)
    {
        timeLast = glfwGetTime();
        return;
    }

    double timeCurrent = glfwGetTime();
    bool   bPrint = false;

    timeElapsed += timeCurrent - timeLast;
    timePrintElapsed += timeCurrent - timeLast;
    timeLast = timeCurrent;

    if(timeElapsed >= TIME_SKIP)
    {
        timeElapsed = 0;

        current++;

        timeCurrent = glfwGetTime();
        timeElapsed += timeCurrent - timeLast;
        timeLast = timeCurrent;
    }

    if(timePrintElapsed >= 1.0)
    {
        timePrintElapsed = 0.0;

        bPrint = true;
    }


    switch(current)
    {
    case 0:
        {
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
                printf("Case 1 The hero's speed of x:%2.4f\n",curVel.x);
				last_velocity=curVel.x;
            }
        }
        break;
    case 1:
        {
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
				current_velocity=curVel.x;
				temp_velocity=current_velocity-last_velocity;
				printf("last_velocity%2.4f\n",last_velocity);
				printf("current_velocity=%2.4f\n",current_velocity);
				printf("current_velocity-last_velocity=%2.4f\n",temp_velocity);
				if(temp_velocity==0){
					printf("Pass\nCase 1 :no input from no input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}	
				else if(temp_velocity!=0){
					printf("Fail\nCase 1 :no input from no input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}	
                current++;
                timeElapsed = 0;
            }
        }
        break;
    case 2:
        {
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
                printf("Case 2 The hero's speed of x:%2.4f\n",curVel.x);
				last_velocity=curVel.x;
            }
        }
        break;
    case 3:
        {
            s_env->processKB(GLFW_KEY_A,0,GLFW_PRESS,0);

            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
				current_velocity=curVel.x;
				temp_velocity=current_velocity-last_velocity;
				printf("last_velocity%2.4f\n",last_velocity);
				printf("current_velocity=%2.4f\n",current_velocity);
				printf("current_velocity-last_velocity=%2.4f\n",temp_velocity);
				if(temp_velocity<0){
					printf("Pass\ncase 2:left input from no input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}	
				else if(temp_velocity>=0){
					printf("Fail\ncase 2:left input from no input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}	
                current++;
                timeElapsed = 0;
                s_env->processKB(GLFW_KEY_A,0,GLFW_RELEASE,0);
            }
        }
        break;
    case 4:
        {
            s_env->processKB(GLFW_KEY_A,0,GLFW_PRESS,0);
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
                printf("Case 3 The hero's speed of x:%2.4f\n",curVel.x);
				last_velocity=curVel.x;
            }
        }
        break;
    case 5:
        {
            s_env->processKB(GLFW_KEY_A,0,GLFW_PRESS,0);
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
				current_velocity=curVel.x;
				temp_velocity=current_velocity-last_velocity;
				printf("last_velocity%2.4f\n",last_velocity);
				printf("current_velocity=%2.4f\n",current_velocity);
				printf("current_velocity-last_velocity=%2.4f\n",temp_velocity);
				if(temp_velocity==0){
					printf("Pass\ncase 3:left input from left input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}	
				else if(temp_velocity!=0){
					printf("Fail\ncase 3:left input from left input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}				
                current++;
                timeElapsed = 0;
                s_env->processKB(GLFW_KEY_A,0,GLFW_RELEASE,0);
            }
        }
        break;
    case 6:
        {
            s_env->processKB(GLFW_KEY_A,0,GLFW_PRESS,0);
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
                printf("Case 4 The hero's speed of x:%2.4f\n",curVel.x);
				last_velocity=curVel.x;
            }
        }
        break;
    case 7:
        {
            s_env->processKB(GLFW_KEY_A,0,GLFW_RELEASE,0);
            s_env->processKB(GLFW_KEY_D,0,GLFW_PRESS,0);
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
				current_velocity=curVel.x;
				temp_velocity=current_velocity-last_velocity;
				printf("last_velocity%2.4f\n",last_velocity);
				printf("current_velocity=%2.4f\n",current_velocity);
				printf("current_velocity-last_velocity=%2.4f\n",temp_velocity);
				if(temp_velocity>0){
					printf("Pass\ncase 4:right input from left input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}	
				else if(temp_velocity<=0){
					printf("Fail\ncase 4:right input from left input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}						
				

                current++;
                timeElapsed = 0;
                s_env->processKB(GLFW_KEY_D,0,GLFW_RELEASE,0);
            }
        }
        break;
    case 8:
        {
            s_env->processKB(GLFW_KEY_A,0,GLFW_PRESS,0);
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
                printf("Case 5 The hero's speed of x:%2.4f\n",curVel.x);
				last_velocity=curVel.x;
            }

        }
        break;
    case 9:
        {
            s_env->processKB(GLFW_KEY_A,0,GLFW_RELEASE,0);
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
				current_velocity=curVel.x;
				temp_velocity=current_velocity-last_velocity;
				printf("last_velocity%2.4f\n",last_velocity);
				printf("current_velocity=%2.4f\n",current_velocity);
				printf("current_velocity-last_velocity=%2.4f\n",temp_velocity);
				if(temp_velocity>0){
					printf("Pass\nCase 5:no input from left input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}	
				else if(temp_velocity<=0){
					printf("Fail\nCase 5:no input from left input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}						
				

                
				if (time_flag_for_case5==0){
					timeElapsed=9.5;
					time_flag_for_case5==1;
				}
				////current++;
                //timeElapsed = 0;
				//s_env->processKB(GLFW_KEY_L,0,GLFW_RELEASE,0);
            }
        }
        break;
    case 10:
        {
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
                printf("Case 6 The hero's speed of x:%2.4f\n",curVel.x);
				last_velocity=curVel.x;
            }
        }
        break;
    case 11:
        {
            s_env->processKB(GLFW_KEY_D,0,GLFW_PRESS,0);

            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
				current_velocity=curVel.x;
				temp_velocity=current_velocity-last_velocity;
				printf("last_velocity%2.4f\n",last_velocity);
				printf("current_velocity=%2.4f\n",current_velocity);
				printf("current_velocity-last_velocity=%2.4f\n",temp_velocity);
				if(temp_velocity>0){
					printf("Pass\ncase 6:right input from no input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}	
				else if(temp_velocity<=0){
					printf("Fail\ncase 6:right input from no input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}						

					
                current++;
                timeElapsed = 0;
                s_env->processKB(GLFW_KEY_D,0,GLFW_RELEASE,0);
            }
        }
        break;
    case 12:
        {
            s_env->processKB(GLFW_KEY_D,0,GLFW_PRESS,0);
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
                printf("Case 7 The hero's speed of x:%2.4f\n",curVel.x);
				last_velocity=curVel.x;
            }
        }
        break;
    case 13:
        {
            s_env->processKB(GLFW_KEY_D,0,GLFW_PRESS,0);

            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
				current_velocity=curVel.x;
				temp_velocity=current_velocity-last_velocity;
				printf("last_velocity%2.4f\n",last_velocity);
				printf("current_velocity=%2.4f\n",current_velocity);
				printf("current_velocity-last_velocity=%2.4f\n",temp_velocity);
				if(temp_velocity==0){
					printf("Pass\ncase 7:right input from right input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}	
				else if(temp_velocity!=0){
					printf("Fail\ncase 7:right input from right input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}						

				
                current++;
                timeElapsed = 0;
                s_env->processKB(GLFW_KEY_D,0,GLFW_RELEASE,0);
            }
        }
        break;
    case 14:
        {
            s_env->processKB(GLFW_KEY_D,0,GLFW_PRESS,0);
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
                printf("Case 8 The hero's speed of x:%2.4f\n",curVel.x);
				last_velocity=curVel.x;
            }
        }
        break;
    case 15:
        {
            s_env->processKB(GLFW_KEY_D,0,GLFW_RELEASE,0);
            s_env->processKB(GLFW_KEY_A,0,GLFW_PRESS,0);
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
				current_velocity=curVel.x;
				temp_velocity=current_velocity-last_velocity;
				printf("last_velocity%2.4f\n",last_velocity);
				printf("current_velocity=%2.4f\n",current_velocity);
				printf("current_velocity-last_velocity=%2.4f\n",temp_velocity);
				if(temp_velocity<0){
					printf("Pass\ncase 8:left input from right input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}	
				else if(temp_velocity>=0){
					printf("Fail\ncase 8:left input from right input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}						

                current++;
                timeElapsed = 0;
                s_env->processKB(GLFW_KEY_A,0,GLFW_RELEASE,0);
            }
        }
        break;
    case 16:
        {
            s_env->processKB(GLFW_KEY_D,0,GLFW_PRESS,0);
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
                printf("Case 9 The hero's speed of x:%2.4f\n",curVel.x);
				last_velocity=curVel.x;
            }
        }
        break;
    case 17:
        {
            s_env->processKB(GLFW_KEY_L,0,GLFW_RELEASE,0);
            if(bPrint==true)
            {
                cpVect curVel = cpBodyGetVelocity(s_hero->body);
				current_velocity=curVel.x;
				temp_velocity=current_velocity-last_velocity;
				printf("last_velocity%2.4f\n",last_velocity);
				printf("current_velocity=%2.4f\n",current_velocity);
				printf("current_velocity-last_velocity=%2.4f\n",temp_velocity);
				if(temp_velocity==0){
					printf("Pass\nCase 9:no input from right input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}	
				else if(temp_velocity!=0){
					printf("Fail\nCase 9:no input from right input,the change of hero's velocity:%2.4f\n\n",temp_velocity);}
					
				if (time_flag_for_case5==0){
					timeElapsed=9.5;
					time_flag_for_case5==1;
				}
				//current++;
                //timeElapsed = 0;
            }
        }
        break;
    default:
        {
            s_env->processKB(GLFW_KEY_D,0,GLFW_RELEASE,0);
        }
        break;
    }
}

bool IsTesting()
{
    return bTesting;
}
