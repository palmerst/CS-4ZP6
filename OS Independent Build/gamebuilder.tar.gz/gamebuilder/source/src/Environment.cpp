#include "Environment.h"
#include "Loader.h"
#include "Shader.h"

#include <stdio.h>
#include <iostream>
#include <string>


