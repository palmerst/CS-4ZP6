#include "StandardObject.h"


void StandardObject::render(){

    Obj::render(position, angle);

}
