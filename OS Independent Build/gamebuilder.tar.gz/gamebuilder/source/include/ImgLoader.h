#ifndef IMGLOADER_H_INCLUDED
#define IMGLOADER_H_INCLUDED

GLuint loadImage(const char* imageFileName);

#endif // IMGLOADER_H_INCLUDED
