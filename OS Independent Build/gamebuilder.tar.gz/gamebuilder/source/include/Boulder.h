#ifndef BOULDER_H_INCLUDED
#define BOULDER_H_INCLUDED

#include "DynamicObject.h"

class Boulder : public DynamicObject {

    public:

        Boulder(float x, float y);

};

#endif // BOULDER_H_INCLUDED
