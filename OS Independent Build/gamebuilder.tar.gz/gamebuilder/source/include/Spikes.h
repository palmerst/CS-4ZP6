#ifndef SPIKES_H_INCLUDED
#define SPIKES_H_INCLUDED

#include "StaticObject.h"

class Spikes : public StaticObject {

    public:

        Spikes(float x, float y, float rotation = 0.0f);

};

#endif // SPIKES_H_INCLUDED
